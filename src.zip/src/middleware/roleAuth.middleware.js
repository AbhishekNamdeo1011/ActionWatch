/**
 * Role-based authorization middleware factory
 * Usage: router.post('/admin-route', authMiddleware, authorize('admin'), controllerFn)
 */
function authorize(...allowedRoles) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ message: "Unauthorized: No user found" });
        }

        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({ 
                message: `Forbidden: Access denied. Required role: ${allowedRoles.join(' or ')}. Your role: ${req.user.role}` 
            });
        }

        next();
    };
}

export { authorize };
