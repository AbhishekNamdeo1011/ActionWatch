import {testMail} from "../controllers/notification.controller.js";

import express from "express";


const router =
    express.Router();
router.get("/test-mail", testMail);

export default router;